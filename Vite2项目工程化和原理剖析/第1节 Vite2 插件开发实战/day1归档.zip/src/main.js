import { createApp } from "vue";
import App from "./App.vue";

// import vm from "virtual-module";

// console.log(vm);

// 全局样式
import "./index.css";

createApp(App).mount("#app");
