const hello = 'hello'
console.log(hello);