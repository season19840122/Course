<template>
  <div>{{ msg }}</div>
</template>

<script>
export default {
  data() {
    return {
      msg: "message"
    };
  }
};
</script>

<style scoped>
</style>